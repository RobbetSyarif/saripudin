//user memasukan text	
			var nama = prompt("Masukan Nama Tanpa Spasi");
			$(".hi").hide();
			//membuat tombol mulai
			setTimeout(function(){
				var par = document.querySelector(".cntn");
				var btn = document.createElement("button");
				var tbtn= document.createTextNode("M U L A I");
				
				btn.appendChild(tbtn);				
				btn.classList.add("btn");
				par.appendChild(btn);
				
				//ketika button mulai di klik
				$(".btn").on("click",function(){
					$(this).css("transform","scale(-0.5)");
					setTimeout(function(){
						$(".btn").remove();
					},300);		
					setTimeout(function(){
							 //menampilkan huruf	
						$(".hi").show();
			    //jeda animasi selama 1 detik dan hujan 3 detik				
						setTimeout(function(){
							textGelombang(nama);
							setTimeout(effekHujan,3000);
						},1500)
					},700)
				})						 							
			},500)
			//cek jumlah karakter text yang user masukan
			if(nama.length > 15){
				nama = prompt("Masukan Nama (Harus <15 Karakter)");
			}
			